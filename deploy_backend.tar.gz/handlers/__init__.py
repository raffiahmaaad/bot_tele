"""
Handlers Package
All bot type handlers are organized in sub-packages.
"""

# Bot types available:
# - store: Digital product store with QRIS payment
# - custom: Minimal template for custom bots
