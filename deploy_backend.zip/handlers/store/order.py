"""
Store Bot - Order Handler.
Handles purchases, payments, and order history.
"""

import os
import uuid
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes

from database_pg import (
    get_product_by_id,
    get_bot_user,
    create_order,
    get_order_by_order_id,
    get_orders_by_user,
    update_order_status,
    get_available_stock,
    mark_stock_sold
)
from services.pakasir import PakasirClient
from utils.qr_generator import generate_qr_image
from utils.keyboard import (
    create_confirm_purchase_keyboard,
    create_payment_keyboard,
    create_back_keyboard
)


def generate_order_id() -> str:
    """Generate unique order ID."""
    timestamp = datetime.now().strftime("%y%m%d")
    unique = uuid.uuid4().hex[:6].upper()
    return f"ORD{timestamp}{unique}"


async def show_buy_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show purchase confirmation."""
    query = update.callback_query
    await query.answer()
    
    # Extract product ID
    product_id = int(query.data.split("_")[1])
    product = get_product_by_id(product_id)
    
    if not product:
        await query.edit_message_text("❌ Produk tidak ditemukan.")
        return
    
    stock = product.get('stock', 0)
    if stock == 0:
        await query.edit_message_text(
            "❌ Maaf, stok produk habis.",
            reply_markup=create_back_keyboard(f"cat_{product['category_id']}")
        )
        return
    
    # Format price
    price_str = f"Rp {product['price']:,}".replace(",", ".")
    
    text = (
        f"🛒 *Konfirmasi Pembelian*\n\n"
        f"📦 *Produk:* {product['name']}\n"
        f"💰 *Harga:* {price_str}\n\n"
        f"_Biaya tambahan dari payment gateway akan ditampilkan saat pembayaran._\n\n"
        f"Lanjutkan pembayaran?"
    )
    
    await query.edit_message_text(
        text,
        parse_mode="Markdown",
        reply_markup=create_confirm_purchase_keyboard(product_id)
    )


async def process_purchase(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process purchase and generate QRIS."""
    query = update.callback_query
    await query.answer("⏳ Memproses pembayaran...")
    
    bot_id = context.bot_data.get('bot_id')
    pakasir_slug = context.bot_data.get('pakasir_slug')
    pakasir_api_key = context.bot_data.get('pakasir_api_key')
    
    # Extract product ID
    product_id = int(query.data.split("_")[2])  # confirm_buy_<id>
    product = get_product_by_id(product_id)
    
    if not product:
        await query.edit_message_text("❌ Produk tidak ditemukan.")
        return
    
    # Get bot user
    bot_user_id = context.user_data.get('bot_user_id')
    if not bot_user_id:
        bot_user = get_bot_user(bot_id, update.effective_user.id)
        if not bot_user:
            await query.edit_message_text("❌ User tidak ditemukan. Silakan /start ulang.")
            return
        bot_user_id = bot_user['id']
    
    # Generate unique order ID
    order_id = generate_order_id()
    
    # Show processing message
    await query.edit_message_text(
        "⏳ *Membuat pembayaran QRIS...*\n\nMohon tunggu sebentar.",
        parse_mode="Markdown"
    )
    
    # Create Pakasir client for this bot
    pakasir = PakasirClient(pakasir_slug, pakasir_api_key)
    
    # Create transaction via Pakasir
    payment = await pakasir.create_transaction(
        order_id=order_id,
        amount=product['price']
    )
    
    if not payment:
        await query.edit_message_text(
            "❌ *Gagal membuat pembayaran*\n\n"
            "Terjadi kesalahan saat menghubungi payment gateway. "
            "Silakan coba lagi nanti.",
            parse_mode="Markdown",
            reply_markup=create_back_keyboard(f"prod_{product_id}")
        )
        return
    
    # Parse expired_at
    try:
        expired_at = datetime.fromisoformat(payment.expired_at.replace("Z", "+00:00"))
    except:
        expired_at = None
    
    # Save order to database
    order = create_order(
        bot_id=bot_id,
        bot_user_id=bot_user_id,
        product_id=product_id,
        order_id=order_id,
        amount=product['price'],
        fee=payment.fee,
        total=payment.total_payment,
        qris_string=payment.payment_number,
        expired_at=expired_at
    )
    
    # Generate QR code image
    qr_image = generate_qr_image(payment.payment_number)
    
    # Format amounts
    amount_str = f"Rp {product['price']:,}".replace(",", ".")
    fee_str = f"Rp {payment.fee:,}".replace(",", ".")
    total_str = f"Rp {payment.total_payment:,}".replace(",", ".")
    
    # Create payment message
    payment_text = (
        f"💳 *Pembayaran QRIS*\n\n"
        f"🆔 *Order:* `{order_id}`\n"
        f"📦 *Produk:* {product['name']}\n\n"
        f"💰 *Harga:* {amount_str}\n"
        f"📋 *Biaya Admin:* {fee_str}\n"
        f"━━━━━━━━━━━━━━━\n"
        f"💵 *Total Bayar:* {total_str}\n\n"
        f"📱 *Scan QR di bawah dengan aplikasi e-wallet atau mobile banking Anda*\n\n"
        f"⏰ *Berlaku hingga:* {expired_at.strftime('%H:%M WIB') if expired_at else 'N/A'}\n\n"
        f"_Setelah pembayaran berhasil, produk akan dikirim otomatis._"
    )
    
    # Delete previous message
    await query.delete_message()
    
    # Send QR code as photo
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo=qr_image,
        caption=payment_text,
        parse_mode="Markdown",
        reply_markup=create_payment_keyboard(order_id)
    )


async def check_payment_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check payment status manually."""
    query = update.callback_query
    await query.answer("🔄 Memeriksa status...")
    
    pakasir_slug = context.bot_data.get('pakasir_slug')
    pakasir_api_key = context.bot_data.get('pakasir_api_key')
    
    # Extract order ID
    order_id = query.data.split("_")[1]  # check_<order_id>
    
    order = get_order_by_order_id(order_id)
    
    if not order:
        await query.message.reply_text("❌ Order tidak ditemukan.")
        return
    
    if order['status'] == "paid":
        await query.message.reply_text(
            f"✅ *Pembayaran Sudah Berhasil!*\n\n"
            f"Order `{order_id}` sudah terbayar dan produk sudah dikirim.",
            parse_mode="Markdown"
        )
        return
    
    # Check status from Pakasir
    pakasir = PakasirClient(pakasir_slug, pakasir_api_key)
    status = await pakasir.get_transaction_status(order_id, order['amount'])
    
    if status and status.status == "completed":
        # Update order status
        update_order_status(order_id, "paid", datetime.now())
        
        # Get and deliver stock
        stock_item = get_available_stock(order['product_id'])
        if stock_item:
            mark_stock_sold(stock_item['id'], order['id'])
            
            await query.message.reply_text(
                f"✅ *Pembayaran Berhasil!*\n\n"
                f"Order: `{order_id}`\n\n"
                f"📦 *Produk Anda:*\n"
                f"```\n{stock_item['content']}\n```",
                parse_mode="Markdown"
            )
        else:
            await query.message.reply_text(
                f"✅ *Pembayaran Berhasil!*\n\n"
                f"Order: `{order_id}`\n\n"
                f"⚠️ Mohon hubungi admin untuk pengiriman produk.",
                parse_mode="Markdown"
            )
    else:
        await query.message.reply_text(
            f"⏳ *Pembayaran Belum Diterima*\n\n"
            f"Order `{order_id}` masih menunggu pembayaran.\n"
            f"Silakan scan QRIS dan selesaikan pembayaran.",
            parse_mode="Markdown"
        )


async def cancel_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel a pending payment."""
    query = update.callback_query
    await query.answer()
    
    pakasir_slug = context.bot_data.get('pakasir_slug')
    pakasir_api_key = context.bot_data.get('pakasir_api_key')
    
    # Extract order ID
    order_id = query.data.split("_")[1]  # cancel_<order_id>
    
    order = get_order_by_order_id(order_id)
    
    if not order:
        await query.message.reply_text("❌ Order tidak ditemukan.")
        return
    
    if order['status'] != "pending":
        await query.message.reply_text(
            f"⚠️ Order `{order_id}` tidak dapat dibatalkan (status: {order['status']})",
            parse_mode="Markdown"
        )
        return
    
    # Cancel on Pakasir
    pakasir = PakasirClient(pakasir_slug, pakasir_api_key)
    await pakasir.cancel_transaction(order_id, order['amount'])
    
    # Update local status
    update_order_status(order_id, "cancelled")
    
    await query.message.reply_text(
        f"✅ *Order Dibatalkan*\n\n"
        f"Order `{order_id}` telah dibatalkan.",
        parse_mode="Markdown",
        reply_markup=create_back_keyboard()
    )


async def show_my_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's order history."""
    query = update.callback_query
    await query.answer()
    
    bot_id = context.bot_data.get('bot_id')
    bot_user_id = context.user_data.get('bot_user_id')
    
    if not bot_user_id:
        bot_user = get_bot_user(bot_id, update.effective_user.id)
        if not bot_user:
            await query.edit_message_text(
                "❌ User tidak ditemukan. Silakan /start.",
                reply_markup=create_back_keyboard()
            )
            return
        bot_user_id = bot_user['id']
    
    orders = get_orders_by_user(bot_id, bot_user_id)
    
    if not orders:
        await query.edit_message_text(
            "📋 *Pesanan Saya*\n\n📭 Anda belum memiliki pesanan.",
            parse_mode="Markdown",
            reply_markup=create_back_keyboard()
        )
        return
    
    text = "📋 *Pesanan Saya*\n\n"
    
    status_emoji = {
        "pending": "⏳",
        "paid": "✅",
        "cancelled": "❌",
        "expired": "⌛"
    }
    
    for order in orders[:10]:  # Show last 10 orders
        emoji = status_emoji.get(order['status'], "❓")
        amount_str = f"Rp {order['amount']:,}".replace(",", ".")
        date_str = order['created_at'].strftime("%d/%m/%Y") if order.get('created_at') else "N/A"
        product_name = order.get('product_name', 'Unknown')
        
        text += f"{emoji} `{order['order_id']}`\n"
        text += f"   📦 {product_name}\n"
        text += f"   💰 {amount_str} | {date_str}\n\n"
    
    await query.edit_message_text(
        text,
        parse_mode="Markdown",
        reply_markup=create_back_keyboard()
    )
