"""Utility functions module"""
